/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.filehanding_thread;

/**
 *
 * @author OS
 */
public class FileHanding_Thread {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
