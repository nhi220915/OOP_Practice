/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Thread;

/**
 *
 * @author OS
 */
class SumThread extends Thread {
    private final int n;
    private long sum;

    public SumThread(int n) {
        this.n = n;
    }

    @Override
    public void run() {
        sum = 0;
        for (int i = 1; i <= n; i++) {
            sum += i;
        }
        System.out.println("Tong tu 1 den " + n + " la: " + sum);
    }
}

public class practice_1_SumThread {
    public static void main(String[] args) {
        int n = 10; 
        SumThread thread = new SumThread(n);
        thread.start();
    }
}