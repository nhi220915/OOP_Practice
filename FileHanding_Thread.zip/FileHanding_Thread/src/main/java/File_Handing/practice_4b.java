/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package File_Handing;

import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author OS
 */
public class practice_4b {
    public static void main(String[] args) {
        String content = "Chao mung\n";
        String path = "src/main/java/File_Handing/outp.txt"; 

        try (FileWriter fw = new FileWriter(path)) {
            fw.write(content);
        } catch (IOException e) {
        }
    }
}
