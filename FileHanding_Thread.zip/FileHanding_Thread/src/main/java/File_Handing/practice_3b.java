/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package File_Handing;

import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author OS
 */
public class practice_3b {
    public static void main(String[] args) {
        String path = "src/main/java/File_Handing/data.txt"; 

        try (FileReader fr = new FileReader(path)) {
            int ch;
            while ((ch = fr.read()) != -1) {
                System.out.print((char) ch);
            }
        } catch (IOException e) {
        }
    }
}
