/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class_Object;

/**
 *
 * @author OS
 */
public class Fraction {
    private int numer;   // tử số
    private int denomin; // mẫu số

    public Fraction(int numer, int denominator) {
        this.numer = numer;
        this.denomin = denominator;
        reduce(); // Rút gọn phân số ngay khi tạo
    }

    public int getNumerator() {
        return numer;
    }

    public void setNumerator(int numerator) {
        this.numer = numerator;
        reduce(); 
    }

    public int getDenominator() {
        return denomin;
    }

    public void setDenominator(int denominator) {
        if (denominator == 0) {
            throw new IllegalArgumentException("Mẫu số không thể bằng 0");
        }
        this.denomin = denominator;
        reduce(); 
    }

    // Phương thức rút gọn phân số
    private void reduce() {
        int gcd = gcd(numer, denomin); // Tìm ước chung lớn nhất
        numer /= gcd;
        denomin /= gcd;

        // Nếu mẫu số âm thì chuyển dấu cho tử số
        if (denomin < 0) {
            numer = -numer;
            denomin = -denomin;
        }
    }

    // gọi hàm tính ước chung lớn nhất (gcd)
    private int gcd(int a, int b) {
        if (b == 0) {
            return a;
        }
        return gcd(b, a % b);
    }

    // nghịch đảo phân số
    public Fraction inverse() {
        return new Fraction(denomin, numer);
    }

    // cộng 2 phân số
    public Fraction add(Fraction other) {
        int newNumerator = this.numer * other.denomin + other.numer * this.denomin;
        int newDenominator = this.denomin * other.denomin;
        return new Fraction(newNumerator, newDenominator);
    }

    // trừ 2 phân số
    public Fraction sub(Fraction other) {
        int newNumerator = this.numer * other.denomin - other.numer * this.denomin;
        int newDenominator = this.denomin * other.denomin;
        return new Fraction(newNumerator, newDenominator);
    }

    // nhân 2 phân số
    public Fraction mul(Fraction other) {
        int newNumerator = this.numer * other.numer;
        int newDenominator = this.denomin * other.denomin;
        return new Fraction(newNumerator, newDenominator);
    }

    // chia 2 phân số
    public Fraction div(Fraction other) {
        return this.mul(other.inverse());
    }

    public void display() {
        System.out.println(numer + "/" + denomin);
    }
}