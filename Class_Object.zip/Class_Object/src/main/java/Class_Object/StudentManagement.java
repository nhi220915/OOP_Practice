/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class_Object;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author OS
 */
public class StudentManagement {
    private ArrayList<Student> studentList;
    
    public StudentManagement() {
        studentList = new ArrayList<>();
    }
    
    // thêm thông tin svien
    public void addStudent() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Nhap ten: ");
        String Name = scanner.nextLine();
        System.out.println("Nhap lop: ");
        String Class = scanner.nextLine();
        System.out.println("Nhap diem trung binh: ");
        double Avg = scanner.nextDouble();
        studentList.add(new Student(Name, Class, Avg));
    }
    
    // hiển thị danh sách all svien
    public void displayStudent() {
        if (studentList.isEmpty()) {
            System.out.println("Khong co sinh vien nao.");
        }
        else {
            for (Student student : studentList) {
                student.displayStudent();
            }
        }
    }
    
    // hiển thị sinh viên có điểm cao nhất
    public void displayHighestScoreStudent() {
        if (studentList.isEmpty()) {
            System.out.println("Khong co sinh vien nao.");
        }
        else {
            Student highest = studentList.get(0);
            for (Student student : studentList) {
                if (student.getavg() > highest.getavg()) {
                    highest = student;
                }
            }
            highest.displayStudent();
        } 
    }
    
    public void displayLowestScoreStudent() {
        if (studentList.isEmpty()) {
            System.out.println("Khong co sinh vien nao.");
        }
        else {
            Student lowest = studentList.get(0);
            for (Student student : studentList) {
                if (student.getavg() < lowest.getavg()) {
                    lowest = student;
                }
            }
            lowest.displayStudent();
        }
    }
    
    // hiển thị svien theo thứ tự giảm dần của avg
    public void displaySortedScore() {
        studentList.sort((s1, s2) -> Double.compare(s2.getavg(), s1.getavg()));
        displayStudent();
    }
    
    // hiển thị tất cả sv
    public void displayStudents() {
        if (studentList.isEmpty()) {
            System.out.println("Khong co sinh vien nao.");
        }
        else {
            for (Student student : studentList) {
                student.displayStudent();
            }
        }
    }
    
    // tìm kiếm sv = tên
    public void searchStudent() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Nhap: ");
        String searchName = scanner.nextLine().toLowerCase();
        
        boolean found = false;
        for (Student student : studentList) {
            if (student.getname().toLowerCase().contains(searchName)) {
                student.displayStudent();
                found = false;
            }
        }
        if (!found) {
            System.out.println("Khong tim thay ket qua");
        }
    }
    
    // chuyển tên thành chữ thường
    public void convertNameToLower() {
        for (Student student : studentList) {
            student.toLowerName();
        }
    }
    
    // chuyển tên thành chữ thường
    public void convertNameToUpper() {
        for (Student student : studentList) {
            student.toUpperName();
        }
    }
    
    //xóa sinh viên có điểm trung bình < 5
    public void removeLowScoreStudent() {
        studentList.removeIf(student -> student.getavg() < 5);
    }
    
    // menu
    public void showMenu() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\n--------------------------MENU-----------------------");
            System.out.println("An 1. Nhap ten sinh vien");
            System.out.println("An 2. Hien thi danh sach");
            System.out.println("An 3. Sinh vien co diem cao nhat");
            System.out.println("An 4. Sinh vien co diem thap nhat");
            System.out.println("An 5. Danh sach giam dan theo diem trung binh");
            System.out.println("An 6. Tim kiem");
            System.out.println("An 7. Viet Hoa ten sinh vien");
            System.out.println("An 8. Viet thuong ten sinh vien");
            System.out.println("An 9. Xoa sinh vien < 5 diem");
            System.out.println("------------------------------------------------------");
            System.out.print("Chon: ");
            int choice = scanner.nextInt();
            
            switch (choice) {
                case 1:
                    addStudent();
                    break;
                case 2:
                    displayStudent();
                    break;
                case 3: 
                    displayHighestScoreStudent();
                    break;
                case 4:
                    displayLowestScoreStudent();
                    break;
                case 5:
                    displaySortedScore();
                    break;
                case 6: 
                    searchStudent();
                    break;
                case 7:
                    convertNameToUpper();
                    break;
                case 8:
                    convertNameToLower();
                    break;
                case 9:
                    removeLowScoreStudent();
                    break;
                default:
                    System.out.println("Lua chon khong hop le. Chon lai");
            }
        }
    }
}
