/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class_Object;

/**
 *
 * @author OS
 */
public class Main {
    public static void main(String[] args) {
        MyPoint p1 = new MyPoint();
        MyPoint p2 = new MyPoint(10, 20);
        MyPoint p3 = new MyPoint(10, 20);

        
        p1.display();
        p2.display();
        
        double distanceP1P2 = p1.distance(p2);
        double distanceP2P3 = MyPoint.distance(p2, p3);
        System.out.println("distanceP1P2:" + distanceP1P2);
        System.out.println("distanceP2P3:" + distanceP2P3);
        
        MyCircle cir1 = new MyCircle();
        cir1.display();
        
        MyCircle cir2 = new MyCircle(5, 5, 15);
        cir2.display();
        
        cir2.setX(10);
        cir2.setY(10);
        cir2.setRadius(20);
        System.out.println("(" + cir2.getX() + "," + cir2.getY() + "," + cir2.getRadius());
        
        double distance = cir1.distance(cir2);
        System.out.println("khoang cach giua cir1 va cir2:" + distance);
        
        double area = cir2.area();
        System.out.println("Dien tich cir2:" + area);
        
        MyRectangle r1 = new MyRectangle();  
        r1.display();
        System.out.println("\n Rec1 - area = " + r1.area());
        
        r1.setWidth(10);
        r1.setPos(p2);
        r1.display();
        System.out.println("\n Rec1 - area = " + r1.area());
        
        // Tạo tam giác vuông
        MyTriangle triangle1 = new MyTriangle(3, 4, 5);
        triangle1.display();
        System.out.println("----------------------");

        // Tạo tam giác cân
        MyTriangle triangle2 = new MyTriangle(2, 2, 3);
        triangle2.display();
        System.out.println("----------------------");

        // Tạo tam giác đều
        MyTriangle triangle3 = new MyTriangle(5, 5, 5);
        triangle3.display();
        System.out.println("----------------------");

        // Không phải là tam giác
        MyTriangle triangle4 = new MyTriangle(1, 2, 3);
        triangle4.display();
        
        Fraction f1 = new Fraction(4,8);
        Fraction f2 = new Fraction(3,6);
        
        System.out.println("f1= ");
        f1.display();
         System.out.println("f2= ");
        f2.display();
        
        // cộng 2 phân số
        Fraction sum = f1.add(f2);
        System.out.println("f1 + f2 = ");
        sum.display();
        
        // trừ 2 phân số
        Fraction diff = f1.sub(f2);
        System.out.println("f1 - f2 = ");
        diff.display();
        
        // nhân 2 phân số
        Fraction product = f1.mul(f2);
        System.out.println("f1 * f2 = ");
        product.display();
        
        //chia 2 phân số
        Fraction quotient = f1.div(f2);
        System.out.println("f1 / f2 = ");
        quotient.display();
        
        // nghịch đảo phân số
        f1.inverse();
        System.out.println("nghich dao cua f1 = ");
        f1.display();
        
        StudentManagement m = new StudentManagement();
        m.showMenu();
        
    }
    
}

