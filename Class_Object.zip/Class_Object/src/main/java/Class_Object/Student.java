/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class_Object;

/**
 *
 * @author OS
 */
public class Student {
    private String Name;
    private String Class;
    private double Avg;
    
    public Student(String Name, String Class, double Avg) {
        this.Name = Name;
        this.Class = Class;
        this.Avg = Avg;
    }
    public String getname() {
        return Name;
    }
    public void setname(String Name) {
        this.Name = Name;
    }
    
    public String getclass() {
        return Class;
    }
    public void setclass(String Class) {
        this.Class = Class;
    }
    
    public double getavg() {
        return Avg;
    }
    public void setavg(double Avg) {
        this.Avg = Avg;
    }
    
    // hiển thị thông tin svien
    public void displayStudent(){
        System.out.println("Tên: " + Name + ", Lớp: " + Class + ", Điểm trung bình: " + Avg);
    }
    
    // đổi tên svien thành chữ hoa
    public void toUpperName() {
        this.Name = this.Name.toUpperCase();
    }
    
    //đổi tên svien thành chữ thường
    public void toLowerName() {
        this.Name = this.Name.toLowerCase();
    }
}
