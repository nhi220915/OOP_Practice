/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class_Object;

/**
 *
 * @author OS
 */
public class MyRectangle {
    private MyPoint mPos;
    private int mWidth;
    private int mHeight;
    
    public MyRectangle() {
        mPos = new MyPoint(0, 0);
        mWidth = 100;
        mHeight = 100;    
    }
    
    public MyRectangle(int x, int y, int width, int height) {
        mPos = new MyPoint(x, y);
        mWidth = width;
        mHeight = height;
    }
    
    public int getX() {
        return mPos.getX();
    }
    
    public void setX(int x) {
        mPos.setX(x);
    }
    
    public int getY() {
        return mPos.getY();
    }
    
    public void setY(int y) {
        mPos.setY(y);
    }
    
    public int getWidth() {
        return mWidth;
    }
    
    public void setWidth(int w) {
        mWidth = w;
    }
    
    public int getHeight() {
        return mHeight;
    }
    
    public void setHeight(int h) {
        mHeight = h;
    }
    
    public void display() {
        System.out.println("(" + mPos.getX() + "," + mPos.getY() + "," + mWidth + "," + mHeight + ")");
    }
    
    public int area() {
        return mWidth * mHeight;
    }

    void setPos(MyPoint p) {
        mPos = p;
    }
}
