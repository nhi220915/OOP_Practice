/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class_Object;

/**
 *
 * @author OS
 */
public class MyCircle {
    private int mPosX;
    private int mPosY;
    private int mRas;
    
    public MyCircle() {
        mPosX = 0;
        mPosY = 0;
        mRas = 10;
    }
    
    public MyCircle(int x, int y, int radius) {
        mPosX = x;
        mPosY = y;
        mRas = radius;
    }
    
    public void display() {
        System.out.println("(" + mPosX + "," + mPosY + "," + mRas + ")");
    }
    
    public void setX(int x) {
        mPosX = x;
    }
    
    public int getX() {
        return mPosX;
    }
    
    public void setY(int y) {
        mPosX = y;
    }
    
    public int getY() {
        return mPosY;
    }
    
    public void setRadius(int radius) {
        mRas = radius;
    }
    
    public int getRadius() {
        return mRas;
    }
    
    public double distance(MyCircle c) {
        int dx = mPosX - c.mPosX;
        int dy = mPosY - c.mPosY;
        return Math.sqrt(dx*dx + dy*dy);
    }
    
    public double area() {
        return Math.PI * mRas * mRas;
    }
}
