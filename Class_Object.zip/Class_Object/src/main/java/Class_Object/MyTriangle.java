/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class_Object;

/**
 *
 * @author OS
 */
public class MyTriangle {
    private double a;
    private double b;
    private double c;

    public MyTriangle(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    // kiểm tra loại tam giác
    public String checkTriangleType() {
        if (!isTriangle()) {
            return "Khong phai la tam giac";
        }
        if (a == b && b == c) {
            return "Tam giac deu";
        }
        if (a == b || b == c || a == c) {
            if (isRightTriangle()) {
                return "Tam giac vuong can";
            }
            return "Tam giac can";
        }
        if (isRightTriangle()) {
            return "Tam giac vuong";
        }
        return "Tam giac thuong";
    }

    // kiểm tra có phải là 1 tam giác hay không
    public boolean isTriangle() {
        return (a + b > c) && (a + c > b) && (b + c > a);
    }

    // kiểm tra có phải tam giác vuông hay không
    public boolean isRightTriangle() {
        return (a * a + b * b == c * c) || (a * a + c * c == b * b) || (b * b + c * c == a * a);
    }

    // chu vi tam giác
    public double perimeter() {
        if (!isTriangle()) {
            return 0;
        }
        return a + b + c;
    }

    // diện tích tam giác theo công thức Heron
    public double area() {
        if (!isTriangle()) {
            return 0;
        }
        double p = perimeter() / 2; // Nửa chu vi
        return Math.sqrt(p * (p - a) * (p - b) * (p - c));
    }

    public void display() {
        System.out.println(checkTriangleType());
        System.out.println("Chu vi: " + perimeter());
        System.out.println("Dien tich: " + area());
    }
}
