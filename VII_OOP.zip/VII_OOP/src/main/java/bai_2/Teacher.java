/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai_2;

/**
 *
 * @author OS
 */

public class Teacher extends Person {
    private double salary; // Lương của giáo viên

    // Hàm khởi tạo (Constructor)
    public Teacher(String name, int age, String gender, double salary) {
        super(name, age, gender); // Gọi constructor của lớp cha (Person)
        this.salary = salary;
    }

    // Các phương thức get và set cho thuộc tính salary
    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    // Phương thức in thông tin của Teacher
    @Override
    public void printInfo() {
        super.printInfo(); // In thông tin chung từ lớp Person
        System.out.println("Lương: " + salary);
    }
}