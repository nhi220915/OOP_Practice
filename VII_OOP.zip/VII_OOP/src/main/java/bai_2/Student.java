/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai_2;

/**
 *
 * @author OS
 */
public class Student extends Person {
    private String className; // Lớp học của sinh viên
    private double gpa;       // Điểm trung bình

    // Hàm khởi tạo (Constructor)
    public Student(String name, int age, String gender, String className, double gpa) {
        super(name, age, gender);  // Gọi constructor của lớp cha (Person)
        this.className = className;
        this.gpa = gpa;
    }

    // Các phương thức get và set cho thuộc tính className
    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    // Các phương thức get và set cho thuộc tính gpa
    public double getGpa() {
        return gpa;
    }

    public void setGpa(double gpa) {
        this.gpa = gpa;
    }

    // Phương thức in thông tin của Student
    @Override
    public void printInfo() {
        super.printInfo(); // In thông tin chung từ lớp Person
        System.out.println("Lớp học: " + className);
        System.out.println("Điểm trung bình: " + gpa);
    }
}