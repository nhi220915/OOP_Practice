/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai_2;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author OS
 */
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Student> students = new ArrayList<>();
        ArrayList<Teacher> teachers = new ArrayList<>();

        while (true) {
            // Hiển thị menu
            System.out.println("Menu:");
            System.out.println("1. Nhập danh sách sinh viên");
            System.out.println("2. Nhập danh sách giáo viên");
            System.out.println("3. In danh sách sinh viên");
            System.out.println("4. In danh sách giáo viên");
            System.out.println("5. Thoát");
            System.out.print("Chọn chức năng: ");
            int choice = sc.nextInt();
            sc.nextLine();  // Đọc bỏ dấu enter còn lại

            switch (choice) {
                case 1:
                    // Nhập danh sách sinh viên
                    System.out.println("Nhập số lượng sinh viên: ");
                    int studentCount = sc.nextInt();
                    sc.nextLine(); // Đọc bỏ dấu enter
                    for (int i = 0; i < studentCount; i++) {
                        System.out.println("Nhập thông tin sinh viên thứ " + (i + 1));
                        System.out.print("Họ và tên: ");
                        String name = sc.nextLine();
                        System.out.print("Tuổi: ");
                        int age = sc.nextInt();
                        sc.nextLine(); // Đọc bỏ dấu enter
                        System.out.print("Giới tính: ");
                        String gender = sc.nextLine();
                        System.out.print("Lớp học: ");
                        String className = sc.nextLine();
                        System.out.print("Điểm trung bình: ");
                        double gpa = sc.nextDouble();
                        sc.nextLine(); // Đọc bỏ dấu enter
                        students.add(new Student(name, age, gender, className, gpa));
                    }
                    break;
                case 2:
                    // Nhập danh sách giáo viên
                    System.out.println("Nhập số lượng giáo viên: ");
                    int teacherCount = sc.nextInt();
                    sc.nextLine(); // Đọc bỏ dấu enter
                    for (int i = 0; i < teacherCount; i++) {
                        System.out.println("Nhập thông tin giáo viên thứ " + (i + 1));
                        System.out.print("Họ và tên: ");
                        String name = sc.nextLine();
                        System.out.print("Tuổi: ");
                        int age = sc.nextInt();
                        sc.nextLine(); // Đọc bỏ dấu enter
                        System.out.print("Giới tính: ");
                        String gender = sc.nextLine();
                        System.out.print("Lương: ");
                        double salary = sc.nextDouble();
                        sc.nextLine(); // Đọc bỏ dấu enter
                        teachers.add(new Teacher(name, age, gender, salary));
                    }
                    break;
                case 3:
                    // In danh sách sinh viên
                    System.out.println("Danh sách sinh viên:");
                    for (Student student : students) {
                        student.printInfo();
                        System.out.println("---------------");
                    }
                    break;
                case 4:
                    // In danh sách giáo viên
                    System.out.println("Danh sách giáo viên:");
                    for (Teacher teacher : teachers) {
                        teacher.printInfo();
                        System.out.println("---------------");
                    }
                    break;
                case 5:
                    // Thoát chương trình
                    System.out.println("Thoát chương trình.");
                    return; // Kết thúc chương trình
                default:
                    System.out.println("Lựa chọn không hợp lệ. Vui lòng chọn lại.");
            }
        }
    }
}