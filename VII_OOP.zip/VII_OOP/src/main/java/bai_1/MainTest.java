/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai_1;

import java.util.Arrays;

/**
 *
 * @author OS
 */
public class MainTest {
    public static void main(String[] args) {
        Rectangle[] rectList = new Rectangle[10];
        
        for (int i =0; i < rectList.length; i++) {
            double w = 100 * Math.random();
            double h = 100 * Math.random();
            rectList[i] = new Rectangle(w, h);
        }
        //sxep array
        Arrays.sort(rectList);
        
        System.out.println("Dsach hcn sau khi sxep theo dt: ");
        for (int i = 0; i < rectList.length; i++) {
            System.out.println(rectList[i].toString());
        }
    }
}
