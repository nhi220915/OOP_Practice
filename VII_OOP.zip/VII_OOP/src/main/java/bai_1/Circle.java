/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai_1;

/**
 *
 * @author OS
 */
public class Circle extends Shape {
    private double rad;
    
    public Circle(double radius) {
        this.rad = rad;
    }
    
    @Override
    public double area() {
        
        return Math.PI * rad * rad;
        
    }
    
}
