/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai_1;

/**
 *
 * @author OS
 */
public class Rectangle extends Shape implements Comparable<Shape> {
    private double width;
    private double height;
    
    public Rectangle(double width, double height) {
        this.width = width;
        this.height = height;
    }

    @Override
    public double area() {
        return width * height;
    }

    @Override
    public int compareTo(Shape o) {
        return Double.compare(this.area(), o.area());
    }
    
    @Override
    public String toString() {
        return "Rectangle: Area = " + area();
    }
    
}
