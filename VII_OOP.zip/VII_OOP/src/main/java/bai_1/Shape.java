/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package bai_1;

/**
 *
 * @author OS
 */
public abstract class Shape {
    
    // pthuc trừu tượng để tính dt
    public abstract double area();

    // pt toString để in dt
    public String toString() {
        return "Area: " + area();
    }
}
