/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai_4.View;

/**
 *
 * @author OS
 */
import bai_4.Model.Contact;
import java.util.Scanner;

public class ContactManagerView {
    private Scanner scanner;

    public ContactManagerView() {
        scanner = new Scanner(System.in);
    }

    public int showMenu() {
        System.out.println("\n--- Contact Manager ---");
        System.out.println("1. Add contact");
        System.out.println("2. Eidit Contact");
        System.out.println("3. Delete contact");
        System.out.println("4. Search by Name");
        System.out.println("5. Search by phone number");
        System.out.println("6. Show all contact");
        System.out.println("7. Exit");
        System.out.print("Choose: ");
        return Integer.parseInt(scanner.nextLine());
    }

    public String inputName() {
        System.out.print("Enter name: ");
        return scanner.nextLine();
    }

    public String inputPhoneNumber() {
        System.out.print("Enter phone number: ");
        return scanner.nextLine();
    }

    public void displayContact(Contact contact) {
        if (contact != null) {
            System.out.println(contact);
        } else {
            System.out.println("No valid");
        }
    }

    public void displayContactsList(Iterable<Contact> contacts) {
        for (Contact contact : contacts) {
            System.out.println(contact);
        }
    }

    public void showMessage(String message) {
        System.out.println(message);
    }
}
