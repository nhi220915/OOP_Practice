/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai_4.Main;

import bai_4.Controller.ContactManagerController;
import bai_4.Model.ContactManagerModel;
import bai_4.View.ContactManagerView;

/**
 *
 * @author OS
 */
public class Main {
    public static void main(String[] args) {
        ContactManagerModel model = new ContactManagerModel();
        ContactManagerView view = new ContactManagerView();
        ContactManagerController controller = new ContactManagerController(model, view);

        controller.run();
    }
}
