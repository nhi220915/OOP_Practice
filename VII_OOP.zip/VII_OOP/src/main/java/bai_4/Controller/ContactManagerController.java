/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai_4.Controller;

import bai_4.Model.Contact;
import bai_4.Model.ContactManagerModel;
import bai_4.View.ContactManagerView;

/**
 *
 * @author OS
 */
public class ContactManagerController {
    private ContactManagerModel model;
    private ContactManagerView view;

    public ContactManagerController(ContactManagerModel model, ContactManagerView view) {
        this.model = model;
        this.view = view;
    }

    public void run() {
        while (true) {
            int choice = view.showMenu();
            switch (choice) {
                case 1 -> addContact();
                case 2 -> updateContact();
                case 3 -> deleteContact();
                case 4 -> searchByName();
                case 5 -> searchByPhoneNumber();
                case 6 -> viewContacts();
                case 7 -> {
                    view.showMessage("Exit.");
                    return;
                }
                default -> view.showMessage("Try again");
            }
        }
    }

    private void addContact() {
        String name = view.inputName();
        String phoneNumber = view.inputPhoneNumber();
        model.addContact(new Contact(name, phoneNumber));
        view.showMessage("Added");
    }

    private void updateContact() {
        String name = view.inputName();
        Contact contact = model.findContactByName(name);

        if (contact != null) {
            String newName = view.inputName();
            String newPhoneNumber = view.inputPhoneNumber();
            if (!newName.isEmpty()) contact.setName(newName);
            if (!newPhoneNumber.isEmpty()) contact.setPhoneNumber(newPhoneNumber);
            view.showMessage("Updated.");
        } else {
            view.showMessage("No valid");
        }
    }

    private void deleteContact() {
        String name = view.inputName();
        if (model.deleteContact(name)) {
            view.showMessage("Deleted");
        } else {
            view.showMessage("No valid");
        }
    }

    private void searchByName() {
        String name = view.inputName();
        Contact contact = model.findContactByName(name);
        view.displayContact(contact);
    }

    private void searchByPhoneNumber() {
        String phoneNumber = view.inputPhoneNumber();
        var results = model.searchByPhoneNumber(phoneNumber);
        if (results.isEmpty()) {
            view.showMessage("No valid");
        } else {
            view.displayContactsList(results);
        }
    }

    private void viewContacts() {
        view.displayContactsList(model.getAllContacts());
    }
}
