/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai_4.Model;

import java.util.ArrayList;

/**
 *
 * @author OS
 */

public class ContactManagerModel {
    private ArrayList<Contact> contacts;

    public ContactManagerModel() {
        this.contacts = new ArrayList<>();
    }

    public void addContact(Contact contact) {
        contacts.add(contact);
    }

    public Contact findContactByName(String name) {
        for (Contact contact : contacts) {
            if (contact.getName().equalsIgnoreCase(name)) {
                return contact;
            }
        }
        return null;
    }

    public ArrayList<Contact> searchByPhoneNumber(String phoneNumber) {
        ArrayList<Contact> results = new ArrayList<>();
        for (Contact contact : contacts) {
            if (contact.getPhoneNumber().contains(phoneNumber)) {
                results.add(contact);
            }
        }
        return results;
    }

    public boolean deleteContact(String name) {
        Contact contact = findContactByName(name);
        if (contact != null) {
            contacts.remove(contact);
            return true;
        }
        return false;
    }

    public ArrayList<Contact> getAllContacts() {
        return contacts;
    }
}
