package bai_3;

public class ThiSinh {
    private String tenThiSinh;
    private double diemToan;
    private double diemLy;
    private double diemHoa;

    // Constructor
    public ThiSinh(String tenThiSinh, double diemToan, double diemLy, double diemHoa) {
        this.tenThiSinh = tenThiSinh;
        this.diemToan = diemToan;
        this.diemLy = diemLy;
        this.diemHoa = diemHoa;
    }

    // Tính tổng điểm
    public double tinhTongDiem() {
        return diemToan + diemLy + diemHoa;
    }

    // Hiển thị thông tin thí sinh
    public void inThongTin() {
        System.out.println("Tên: " + tenThiSinh + ", Tổng điểm: " + tinhTongDiem());
    }

    // Getter cho tổng điểm
    public double getTongDiem() {
        return tinhTongDiem();
    }

    // Getter tên
    public String getTenThiSinh() {
        return tenThiSinh;
    }
}
