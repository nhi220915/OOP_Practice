package bai_3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<ThiSinh> danhSachThiSinh = new ArrayList<>();

        // Nhập danh sách thí sinh
        System.out.print("Nhập số lượng thí sinh: ");
        int soThiSinh = Integer.parseInt(scanner.nextLine());
        for (int i = 0; i < soThiSinh; i++) {
            System.out.println("Nhập thông tin thí sinh thứ " + (i + 1) + ": ");
            System.out.print("Tên thí sinh: ");
            String ten = scanner.nextLine();
            System.out.print("Điểm Toán: ");
            double toan = Double.parseDouble(scanner.nextLine());
            System.out.print("Điểm Lý: ");
            double ly = Double.parseDouble(scanner.nextLine());
            System.out.print("Điểm Hóa: ");
            double hoa = Double.parseDouble(scanner.nextLine());

            // Thêm thí sinh vào danh sách
            danhSachThiSinh.add(new ThiSinh(ten, toan, ly, hoa));
        }

        // In danh sách thí sinh
        System.out.println("\nDanh sách thí sinh:");
        for (ThiSinh ts : danhSachThiSinh) {
            ts.inThongTin();
        }

        // Sắp xếp danh sách điểm giảm dần
        Collections.sort(danhSachThiSinh, (a, b) -> Double.compare(b.getTongDiem(), a.getTongDiem()));
        System.out.println("\nDanh sách thí sinh (điểm giảm dần):");
        for (ThiSinh ts : danhSachThiSinh) {
            ts.inThongTin();
        }

        // In danh sách thí sinh trúng tuyển
        System.out.println("\nDanh sách thí sinh trúng tuyển (điểm chuẩn >= 17):");
        for (ThiSinh ts : danhSachThiSinh) {
            if (ts.getTongDiem() >= 17) {
                ts.inThongTin();
            }
        }

        scanner.close();
    }
}
